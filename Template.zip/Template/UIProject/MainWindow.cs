﻿using System;
using System.Windows.Forms;

namespace $safeprojectname$
{
    /// <summary>
    /// The main window of the application.
    /// </summary>
    public partial class MainWindow : Form
    {
        /// <summary>
        /// Empty, static constructor to prohibit direct allocation of this class.
        /// </summary>
        static MainWindow() { }

        /// <summary>
        /// Constructs a new instance of <see cref="T:$safeprojectname$.MainWindow" /> and returns
        /// a reference to it.
        /// </summary>
        protected MainWindow()
            => InitializeComponent();

        /// <summary>
        /// Gets a reference to the one and only instance of
        /// <see cref="T:$safeprojectname$.MainWindow" />.
        /// </summary>
        public static MainWindow Instance { get; } = new MainWindow();

        /// <summary>Raises the <see cref="E:System.Windows.Forms.Form.Load" /> event.</summary>
        /// <param name="e">An <see cref="T:System.EventArgs" /> that contains the event data.</param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            Text = Application.ProductName;
        }

        /// <summary>
        /// Handles the <see cref="E:System.Windows.Forms.Control.Click" /> event raised by
        /// the Say Hello button.
        /// </summary>
        /// <param name="sender">
        /// Reference to an instance of the object that raised the
        /// event.
        /// </param>
        /// <param name="e">
        /// A <see cref="T:System.EventArgs" /> that contains the event
        /// data.
        /// </param>
        /// <remarks>
        /// This handler responds by displaying a <c>MessageBox</c> that "says
        /// hello" to the user.
        /// </remarks>
        private void OnClickSayHelloButton(object sender, EventArgs e)
        {
            MessageBox.Show(
                this, "Hello, world!", Application.ProductName,
                MessageBoxButtons.OK, MessageBoxIcon.Information,
                MessageBoxDefaultButton.Button1
            );
        }
    }
}