﻿using System;

namespace $safeprojectname$
{
    /// <summary>
    /// Class to do data access.
    /// </summary>
    public class DataAccessClass
    {
        /// <summary>
        /// Constructs a new instance of <see cref="T:$safeprojectname$.DataAccessClass" /> and returns a reference to it.
        /// </summary>
        public DataAccessClass()
        {
            // TODO: Add instance initialization code here.
        }

        /// <summary>
        /// Connects to the database.
        /// </summary>
        /// <remarks>
        /// This method does nothing except throw
        /// <see cref="T:System.NotImplementedException" />.
        /// </remarks>
        private void ConnectToDatabase()
            => throw new NotImplementedException();
    }
}